def f(x):
    return 0.3 * x**4 - 0.2 * x**3 + 1.1 * x**2 - x + 3

def primera_derivada(x, h):
    return (f(x + h) - f(x)) / h

def segunda_derivada(x, h):
    return (f(x + h) - 2 * f(x) + f(x - h)) / (h**2)

x = 1.2
h = 0.005

# Valor verdadero de la primera derivada en x = 1.2
verdadero_primera_derivada = 1.2 * (x)**3 - 0.6 * (x)**2 + 2.2 * (x) - 1

# Valor verdadero de la segunda derivada en x = 1.2
verdadero_segunda_derivada = 3.6 * (x)**2 - 1.2 * (x) + 2.2

# Diferencias finitas
primera_derivada_hacia_adelante = primera_derivada(x, h)
primera_derivada_hacia_atras = primera_derivada(x, -h)  # hacia atrás
primera_derivada_centrada = (f(x + h) - f(x - h)) / (2 * h)

segunda_derivada_hacia_adelante = segunda_derivada(x, h)
segunda_derivada_hacia_atras = segunda_derivada(x, -h)  # hacia atrás
segunda_derivada_centrada = (f(x + h) - 2 * f(x) + f(x - h)) / (h**2)

# Imprimir resultados
print("Valor verdadero de la primera derivada en x =", x, ":", verdadero_primera_derivada)
print("Valor verdadero de la segunda derivada en x =", x, ":", verdadero_segunda_derivada)
print("Diferencias finitas:")
print("Primera derivada hacia adelante:", primera_derivada_hacia_adelante)
print("Primera derivada hacia atrás:", primera_derivada_hacia_atras)
print("Primera derivada centrada:", primera_derivada_centrada)
print("Segunda derivada hacia adelante:", segunda_derivada_hacia_adelante)
print("Segunda derivada hacia atrás:", segunda_derivada_hacia_atras)
print("Segunda derivada centrada:", segunda_derivada_centrada)
